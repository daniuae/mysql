# solution.py
"""
Reference implementation for NumpyArrayAnalyzer (matrix-related methods removed).

Students may use this as an example solution or instructors may distribute
a template version derived from it.
"""

import numpy as np
from typing import List, Tuple


class NumpyArrayAnalyzer:
    """
    Implementation for NumPy Array Analysis Assessment, with matrix-related
    methods (reshape_to_matrix, transpose_matrix) removed.
    """

    # -----------------------------------------------------
    # Order-related methods
    # -----------------------------------------------------

    def create_order_array(self, amounts: List[float]) -> np.ndarray:
        return np.array(amounts, dtype=float)

    def validate_order_array(self, order_array: np.ndarray) -> bool:
        if order_array is None or order_array.size == 0:
            return False
        return bool((order_array >= 0).all())

    def apply_discount(self, order_array: np.ndarray) -> np.ndarray:
        arr = order_array.astype(float).copy()
        mask = arr >= 150.0
        arr[mask] = arr[mask] * 0.9
        return arr

    def format_order_amounts(self, order_array: np.ndarray) -> np.ndarray:
        return np.array([f"${float(x):.2f}" for x in order_array], dtype=object)

    def compute_order_summary(self, order_array: np.ndarray) -> Tuple[float, float, float]:
        arr = order_array.astype(float)
        if arr.size == 0:
            return 0.0, 0.0, 0.0
        total = float(arr.sum())
        avg = float(arr.mean())
        mx = float(arr.max())
        return total, avg, mx

    def flag_high_value_orders(self, order_array: np.ndarray, threshold: float = 150.0) -> np.ndarray:
        arr = order_array.astype(float)
        return np.where(arr >= threshold, "High", "Normal")

    # -----------------------------------------------------
    # Stock-related methods
    # -----------------------------------------------------

    def create_stock_array(self, changes: List[float]) -> np.ndarray:
        return np.array(changes, dtype=float)

    def validate_stock_array(self, changes: np.ndarray) -> bool:
        if changes is None or changes.size == 0:
            return False
        return bool(((changes >= -10.0) & (changes <= 10.0)).all())

    def compute_volatility(self, changes: np.ndarray) -> Tuple[float, float, float]:
        arr = changes.astype(float)
        if arr.size == 0:
            return 0.0, 0.0, 0.0
        mean = float(arr.mean())
        std = float(arr.std(ddof=1)) if arr.size > 1 else 0.0
        mx = float(arr.max())
        return mean, std, mx

    def flag_volatile_stocks(self, changes: np.ndarray) -> np.ndarray:
        arr = changes.astype(float)
        abs_arr = np.abs(arr)
        labels = np.empty(arr.shape, dtype=object)
        labels[abs_arr < 2.0] = "Stable"
        labels[(abs_arr >= 2.0) & (abs_arr <= 5.0)] = "Moderate Risk"
        labels[abs_arr > 5.0] = "High Risk"
        return labels

    def longest_loss_streak(self, changes: np.ndarray) -> int:
        arr = changes.astype(float)
        longest = 0
        current = 0
        for x in arr:
            if x < 0:
                current += 1
                if current > longest:
                    longest = current
            else:
                current = 0
        return int(longest)

    def format_stock_report(self, changes: np.ndarray) -> np.ndarray:
        return np.array([f"{float(x):.2f}%" for x in changes], dtype=object)

    # -----------------------------------------------------
    # Additional NumPy practice methods (no matrix methods)
    # -----------------------------------------------------

    def create_sequential_array(self, start: int, stop: int, step: int = 1) -> np.ndarray:
        return np.arange(start, stop, step, dtype=float)

    def compute_elementwise_square(self, arr: np.ndarray) -> np.ndarray:
        return arr ** 2

    def compute_statistics(self, arr: np.ndarray) -> Tuple[float, float, float, float]:
        arr = arr.astype(float)
        if arr.size == 0:
            return 0.0, 0.0, 0.0, 0.0
        total = float(arr.sum())
        mean = float(arr.mean())
        mn = float(arr.min())
        mx = float(arr.max())
        return total, mean, mn, mx

    def filter_above_threshold(self, arr: np.ndarray, threshold: float) -> np.ndarray:
        return arr[arr > threshold]

    def replace_negatives_with_zero(self, arr: np.ndarray) -> np.ndarray:
        return np.where(arr < 0, 0.0, arr)

    def normalize_array(self, arr: np.ndarray) -> np.ndarray:
        arr = arr.astype(float)
        if arr.size == 0:
            return arr
        mn = arr.min()
        mx = arr.max()
        if mx == mn:
            return np.zeros_like(arr, dtype=float)
        return (arr - mn) / (mx - mn)

    def concatenate_arrays(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return np.concatenate([a, b])

    def compute_dot_product(self, a: np.ndarray, b: np.ndarray) -> float:
        return float(np.dot(a, b))

    def get_unique_values(self, arr: np.ndarray) -> np.ndarray:
        return np.unique(arr)

    def sort_array(self, arr: np.ndarray) -> np.ndarray:
        return np.sort(arr)

    def count_nonzero(self, arr: np.ndarray) -> int:
        return int(np.count_nonzero(arr))
